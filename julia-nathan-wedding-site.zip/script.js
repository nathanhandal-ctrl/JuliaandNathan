// Simple site state in localStorage
const KEY = 'wedding_site_state_v1';

const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

function toggleNav(){ $('#navMenu').classList.toggle('open'); }
function togglePanel(){ $('#editPanel').classList.toggle('open'); }
$('#editToggle').addEventListener('click', togglePanel);

function defaultState(){
  return {
    colors: { brand:'#f6d6de', cream:'#fff6e9', bg:'#a7b9a6' },
    rsvp: 'https://forms.gle/',
    map: '',
    photos: [], // data URLs
    qa: [
      {q:'Can I bring a plus-one?', a:'Please check your invitation—plus-ones are noted where possible.'},
      {q:'Are kids welcome?', a:'We love your little ones, but the reception is adults‑only.'},
      {q:'Dress code?', a:'Garden formal. Comfortable shoes encouraged.'},
    ],
    registry: [
      {label:'Zola', url:'#'},
      {label:'Honeyfund', url:'#'}
    ],
    edits: {}
  };
}

function loadState(){
  try{ return JSON.parse(localStorage.getItem(KEY)) || defaultState(); }
  catch(e){ return defaultState(); }
}

function saveState(){ localStorage.setItem(KEY, JSON.stringify(state)); }

let state = loadState();

// Apply theme colors
function applyTheme(){
  const r = document.documentElement;
  r.style.setProperty('--bg', state.colors.bg);
  r.style.setProperty('--cream', state.colors.cream);
  r.style.setProperty('--brand', state.colors.brand);
}

// Editable text fields (contenteditable) mapped by data-edit-key
function initContentEditable(){
  $$('[data-edit-key]').forEach(el=>{
    const key = el.getAttribute('data-edit-key');
    if(state.edits[key]) el.textContent = state.edits[key];
    el.addEventListener('input', ()=>{
      state.edits[key] = el.textContent;
      saveState();
    });
  });
}

// RSVP link
function applyRSVP(){
  const btn = $('#rsvpBtn');
  btn.href = state.rsvp || 'https://forms.gle/';
}

// Map embed
function applyMap(){
  if(state.map && state.map.includes('<iframe')){
    $('.map-embed').innerHTML = state.map;
  }
}

// Photos
function renderPhotos(){
  const grid = $('#photoGrid');
  grid.innerHTML = '';
  state.photos.forEach((src, i)=>{
    const fig = document.createElement('figure');
    fig.className = 'card';
    const img = document.createElement('img');
    img.src = src; img.alt = 'Uploaded photo';
    const cap = document.createElement('figcaption');
    cap.textContent = 'Photo';
    fig.appendChild(img); fig.appendChild(cap);
    grid.appendChild(fig);
  });
}

function clearPhotos(){
  if(confirm('Remove all photos?')){
    state.photos = []; saveState(); renderPhotos();
  }
}
window.clearPhotos = clearPhotos;

// QA
function renderQA(){
  const list = $('#qaList');
  list.innerHTML = '';
  state.qa.forEach(({q,a}, idx)=>{
    const d = document.createElement('details');
    const s = document.createElement('summary'); s.textContent = q;
    const p = document.createElement('p'); p.textContent = a;
    d.appendChild(s); d.appendChild(p);
    list.appendChild(d);
  });
}

function addQA(){
  const q = $('#qText').value.trim();
  const a = $('#aText').value.trim();
  if(!q || !a) return;
  state.qa.push({q,a}); saveState(); renderQA();
  $('#qText').value=''; $('#aText').value='';
}
window.addQA = addQA;

function clearQA(){
  if(confirm('Clear all Q&A?')){
    state.qa = []; saveState(); renderQA();
  }
}
window.clearQA = clearQA;

// Registry
function renderRegistry(){
  const ul = $('#registryList');
  ul.innerHTML = '';
  state.registry.forEach(({label,url})=>{
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = url; a.textContent = label; a.target = '_blank'; a.rel = 'noopener';
    li.appendChild(a); ul.appendChild(li);
  });
}

function addRegistry(){
  const label = $('#regLabel').value.trim();
  const url = $('#regUrl').value.trim();
  if(!label || !url) return;
  state.registry.push({label,url}); saveState(); renderRegistry();
  $('#regLabel').value=''; $('#regUrl').value='';
}
window.addRegistry = addRegistry;

function clearRegistry(){
  if(confirm('Clear all registry items?')){
    state.registry = []; saveState(); renderRegistry();
  }
}
window.clearRegistry = clearRegistry;

// Inputs in panel
$('#colorBrand').addEventListener('input', e=>{ state.colors.brand = e.target.value; saveState(); applyTheme(); });
$('#colorCream').addEventListener('input', e=>{ state.colors.cream = e.target.value; saveState(); applyTheme(); });
$('#colorBg').addEventListener('input', e=>{ state.colors.bg = e.target.value; saveState(); applyTheme(); });

$('#rsvpUrl').addEventListener('change', e=>{ state.rsvp = e.target.value; saveState(); applyRSVP(); });

$('#mapEmbed').addEventListener('change', e=>{
  state.map = e.target.value; saveState(); applyMap();
});

$('#photoInput').addEventListener('change', async e=>{
  const files = Array.from(e.target.files || []);
  for(const f of files){
    const b64 = await fileToDataURL(f);
    state.photos.push(b64);
  }
  saveState(); renderPhotos();
});

function fileToDataURL(file){
  return new Promise((resolve, reject)=>{
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

// Export / Import
function exportData(){
  const blob = new Blob([JSON.stringify(state,null,2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'wedding-site-data.json'; a.click();
  URL.revokeObjectURL(url);
}
window.exportData = exportData;

$('#importFile').addEventListener('change', async e=>{
  const f = e.target.files[0];
  if(!f) return;
  const text = await f.text();
  try{
    state = JSON.parse(text);
    saveState(); initAll();
  }catch(err){ alert('Invalid JSON'); }
});

function initAll(){
  applyTheme();
  initContentEditable();
  applyRSVP();
  applyMap();
  renderPhotos();
  renderQA();
  renderRegistry();
  document.getElementById('year').textContent = new Date().getFullYear();
}

initAll();
