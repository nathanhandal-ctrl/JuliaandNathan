# Julia & Nathan — Wedding Website (Customizable)

Romantic, dreamy, and classy single‑page site with floral elements, muted sage background, pastel pink & cream accents. 
Names in an elegant script; body uses Copperplate Gothic (with sensible fallbacks).

## How to customize **on the website**
1. Open `index.html` in your browser.
2. Click the floating 🎨 button (bottom‑right) to open **Edit Mode**.
3. Brand:
   - Change colors (sage, pink, cream).
4. RSVP:
   - Paste your Google Form link.
5. Map:
   - Paste the Google Maps `<iframe>` embed.
6. Photos:
   - Upload images (saved locally in your browser).
7. Q&A:
   - Add or clear question/answer items.
8. Registry:
   - Add label + URL pairs (Zola, Honeyfund, etc.).
9. Export/Import:
   - Export a JSON backup of your edits and import on another device.

Editable text on the page (like schedule notes) can also be clicked and edited directly. All changes save to **localStorage** (private to your browser) until you export/import.

## Free hosting
- **GitHub Pages** or **Netlify**: drag‑and‑drop deploy. No server needed.

## Fonts
- Names: Great Vibes (Google Fonts)
- Body: Copperplate Gothic if available on your device, otherwise fallbacks (Trajan/Cinzel/serif). 
  If you own a web‑license for Copperplate Gothic, you can self‑host it by adding `@font-face` in `style.css`.

## Notes
- Replace placeholder images in `/assets` with your own (or upload in Edit Mode).
- Colors are controlled by CSS variables at the top of `style.css`.
